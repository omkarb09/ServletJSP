function validate(){
    //alert("In validate function");
    var username=document.getElementById("username").value;
    var passwd=document.getElementById("password").value;
    if(username == "")
    {
        //alert("Please enter usrname");
        
        document.getElementById("usrnm").innerHTML = "Please enter username!";
        return false;
    }
    else if(passwd=="")
    {
        //alert("Password cannot be blank");
        document.getElementById("passwd").innerHTML = "Please enter password!";
        return false;
    }
    else
    {
        var form =document.getElementById("frm");
        form.action="login.do";
        form.submit();
    }
}
