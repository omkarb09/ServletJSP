package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.models.Users;




public class UserDao {
	
	private Connection conn=null;
	private void openConnection() throws SQLException,ClassNotFoundException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		conn= DriverManager.getConnection(url,"hr","hr");
		/*if (conn != null) 
		 {
			    System.out.println("Connected");
		 }*/
		
	}
	
	private void closeConnection()
	{
		try
		{
			conn.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public int readLogin(String username,String password)
	{		
		try 
		{
			openConnection();
			
			String query ="Select * from Users where username=? and password=?";
			PreparedStatement pstmt= conn.prepareStatement(query);
			pstmt.setString(1,username);
			pstmt.setString(2,password);
			
			ResultSet result=pstmt.executeQuery();
			if(result.next())
			{
				pstmt.close();
				return 1;
			}
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
		
		finally 
		{
			closeConnection();
		}
		return 0;
	}
	
	public List<Users> readAllUsers()
	{
		List<Users> users = null;
		try 
		{
			openConnection();
			
			String query="select * from users";
			
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(query);
			
			users= new ArrayList<>();
			while(rs.next())
			{
				String uname=rs.getString("username");
				String fname=rs.getString("firstname");
				String lname=rs.getString("lastname");
				String mobile=rs.getString("mobilenumber");
				
				Users user = new Users(uname,null,fname,lname,mobile);
				users.add(user);
			}
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		finally {
			closeConnection();
		}
		
		return users;
	}
	
	public int deleteUser(String username)
	{
		int result=0;
		try 
		{
			openConnection();
			String query="DELETE FROM USERS WHERE USERNAME=?";
			PreparedStatement pstmt= conn.prepareStatement(query);
			pstmt.setString(1, username);
			result=pstmt.executeUpdate();
			
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		finally {
			closeConnection();
		}
		
		return result;
	}
}
