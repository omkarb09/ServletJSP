package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class LoginDao {
	public int readLogin(String username,String password)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			Connection conn= DriverManager.getConnection(url,"hr","hr");
			
			 if (conn != null) 
			 {
				    System.out.println("Connected");
			 }
			
			//Statement stmt = conn.createStatement();
			
			String query ="Select * from Users where username=? and password=?";
			PreparedStatement pstmt= conn.prepareStatement(query);
			pstmt.setString(1,username);
			pstmt.setString(2,password);
			
			ResultSet result=pstmt.executeQuery();
			if(result.next())
			{
				return 1;
			}
		} 
		
		catch (SQLException e) {
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) {
			// TODO: handle exception
		}
		
		
		return 0;
	}
}
