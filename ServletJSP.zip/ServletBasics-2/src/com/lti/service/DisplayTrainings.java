package com.lti.service;

import java.util.List;

import com.lti.dao.GetData;
import com.lti.model.Training;

public class DisplayTrainings 
{
	GetData obj = null;
	public DisplayTrainings()
	{
		obj = new GetData();
	}
	
	public List<Training> displayTrain()
	{
		return obj.showAllUsers();
	}
}
