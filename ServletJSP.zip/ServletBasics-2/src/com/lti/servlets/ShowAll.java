package com.lti.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.model.Training;
import com.lti.service.DisplayTrainings;

/**
 * Servlet implementation class ShowAll
 */
public class ShowAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
   	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DisplayTrainings obj = new DisplayTrainings();
		List<Training> list=obj.displayTrain();
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		out.println("<table>");
		for(Training user: list)
		{
			out.println("<tr>");

			out.println("<td>"+user.getTrainingId()+"</td>");
			out.println("<td>"+user.getTrainingName()+"</td>");
			out.println("<td>"+user.getAvailableSeats()+"</td>");
			out.println("<td><a href=''>Enroll</a></td>");
			out.println("</tr>");
			
		}
		out.println("</table>");
		out.println("</body>");
		out.println("</html>");
		
	}

}
