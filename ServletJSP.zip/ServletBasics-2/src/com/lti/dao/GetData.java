package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.model.Training;

public class GetData {
	public List<Training> showAllUsers()
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			Connection conn= DriverManager.getConnection(url,"hr","hr");
			
			String query="select * from training";
			
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(query);
			
			List<Training> show= new ArrayList<>();
			while(rs.next())
			{
				int id=rs.getInt("trainingid");
				String tname=rs.getString("trainingname");
				int aseats=rs.getInt("availableseats");
				
				
				Training user = new Training(id,tname,aseats);
				show.add(user);
			}
			
			return show;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	
	}
}
