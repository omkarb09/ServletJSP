package com.lti.service;

import java.util.List;

import com.lti.dao.TrainingDao;
import com.lti.model.Training;

public class ServiceTrainings 
{
	TrainingDao obj = null;
	public ServiceTrainings()
	{
		obj = new TrainingDao();
	}
	
	public List<Training> displayTrain()
	{
		return obj.showAllUsers();
	}
	
	public void EnrollT(int id,int seat)
	{
		obj.EnrollCount(id, seat);
	}
	
	public boolean removeTraining(int trainingId)
	{
		int result=obj.deleteTraining(trainingId);
		if(result==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
