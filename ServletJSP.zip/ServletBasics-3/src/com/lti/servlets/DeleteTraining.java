package com.lti.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.service.ServiceTrainings;


public class DeleteTraining extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int trainingId=Integer.parseInt(request.getParameter("id"));
		
		ServiceTrainings service = new ServiceTrainings();
		boolean result = service.removeTraining(trainingId);
		
		if(result)
		{
				RequestDispatcher rd = request.getRequestDispatcher("showall.view");
				rd.forward(request, response);
		}
	}

	

}
