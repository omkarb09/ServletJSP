package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.model.Training;

public class TrainingDao {
	
	private Connection conn=null;
	private void openConnection() throws SQLException,ClassNotFoundException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		conn= DriverManager.getConnection(url,"hr","hr");
	}
	
	private void closeConnection()
	{
		try 
		{
			conn.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void EnrollCount(int id,int seat)
	{
		try 
		{
			openConnection();
			seat=seat-1;
			String query="UPDATE TRAINING SET AVAILABLESEATS=? WHERE TRAININGID=?";
			PreparedStatement pstmt= conn.prepareStatement(query);
			pstmt.setInt(1,seat);
			pstmt.setInt(2,id);
			pstmt.executeUpdate();
			
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		finally 
		{
			closeConnection();
		}
	}
	
	public int deleteTraining(int trainingId)
	{
		int result=0;
		try 
		{
			openConnection();
			
			String query="DELETE FROM TRAINING WHERE trainingid=?";
			PreparedStatement pstmt= conn.prepareStatement(query);
			pstmt.setInt(1,trainingId);
			result=pstmt.executeUpdate();
			
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		finally 
		{
			closeConnection();
		}
		
		return result;
	}
	
	
	public List<Training> showAllUsers()
	{
		List<Training> show=null;
		try 
		{
			openConnection();
			
			String query="select * from training";
			
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(query);
			
			show= new ArrayList<>();
			while(rs.next())
			{
				int id=rs.getInt("trainingid");
				String tname=rs.getString("trainingname");
				int aseats=rs.getInt("availableseats");
				
				
				Training user = new Training(id,tname,aseats);
				show.add(user);
			}
			
			
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally 
		{
			closeConnection();
		}
		return show;
	
	}
	
	
}
